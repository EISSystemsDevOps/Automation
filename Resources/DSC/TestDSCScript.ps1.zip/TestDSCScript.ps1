Configuration DBServerConfig
{
 
    Import-DscResource -ModuleName PSDesiredStateConfiguration   

	Node ("localhost")
	{
		Script TempDir
        	{
	            SetScript = { mkdir C:\temp2 }
	            GetScript =  { @{} }
	            TestScript = { $false }
                
        	}
    }
} 