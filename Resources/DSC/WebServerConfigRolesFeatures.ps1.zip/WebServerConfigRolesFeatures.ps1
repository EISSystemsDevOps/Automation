﻿
#Config file for Push mode and Azure setup with extension


Configuration WebServerConfigRolesFeatures
 {
  Param (
         [Parameter(Mandatory=$True)]
         [String[]]$SourcePath,

         [Parameter(Mandatory=$False)]
         [String[]]$SWPath
         )

    Import-DscResource -ModuleName PSDesiredStateConfiguration #, xPendingReboot
 
    Node ("localhost") 
      
    {   
    $WindowsFeatures = "AS-HTTP-Activation", "WAS-NET-Environment", "Web-WebServer", "Web-Common-Http", "Web-Default-Doc", "Web-Dir-Browsing", "Web-Http-Errors", `
					   "Web-Static-Content", "Web-Health", "Web-Http-Logging", "Web-Http-Tracing", "Web-Performance", "Web-Stat-Compression", "Web-Security", "Web-Filtering", "Web-App-Dev", "Web-Net-Ext45", `
					   "Web-Asp-Net45", "Web-ISAPI-Ext", "Web-ISAPI-Filter", "Web-Mgmt-Tools", "Web-Mgmt-Console", "Web-Mgmt-Compat", "Web-Metabase", "NET-Framework-Core", "NET-HTTP-Activation", "NET-Framework-45-Features", `
					   "NET-Framework-45-Core", "NET-Framework-45-ASPNET", "NET-WCF-Services45", "NET-WCF-TCP-PortSharing45", "Web-Net-Ext", "Web-Asp-Net", "Application-Server", "AS-Ent-Services", 
                        "AS-Web-Support", "FileAndStorage-Services", "FS-FileServer", "Web-Server"
    foreach ($WindowsFeature in $WindowsFeatures)
     {
      WindowsFeature $WindowsFeature
		{
			Ensure = "Present"
			Name = "$WindowsFeature"
            Source = "$SourcePath"
            
            
		    }
        }
    }
 }

